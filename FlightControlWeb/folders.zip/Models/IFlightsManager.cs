﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightControlWeb.Models
{
    public interface IFlightsManager
    {
        Flight GetFlightById(string id);
        Server GetServerById(string id);
        FlightPlan GetFlightPlanById(string uniqueId);
        IEnumerable<Server> GetAllServers();
        IEnumerable<Flight> GetAllFlights();
        IEnumerable<FlightPlan> GetAllFlightPlans(); //CHECK if neccessary. ***************************
        void AddFlight(Flight flight);
        void UpdateFlight(Flight flight);
        void DeleteFlight(string flightId);
        void AddFlightPlan(FlightPlan flightPlan);
        void RemoveFlightPlan(string uniqueId);
        void AddServer(Server server);
        void RemoveServer(string id);
    }
}
