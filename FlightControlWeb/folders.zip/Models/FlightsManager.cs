﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace FlightControlWeb.Models
{
    public class FlightsManager : IFlightsManager
    {
        private readonly List<Flight> flightsList = new List<Flight>();
        private readonly List<FlightPlan> flightsPlansList = new List<FlightPlan>();
        private readonly List<Server> serversList = new List<Server>();
        public void AddFlight(Flight flight)
        {
            flightsList.Add(flight);
        }
        public void AddFlightPlan(FlightPlan flightPlan)
        {
            flightsPlansList.Add(flightPlan);
        }
        public void AddServer(Server server)
        {
            serversList.Add(server);
        }
        public void DeleteFlight(string flightId)
        {
            Flight flight = flightsList.Where(x => x.FlightId == flightId).FirstOrDefault();
            if (flight == null)
            {
                Debug.WriteLine("flight isn't found.\n");
            } else
            {
                flightsList.Remove(flight);
            }
        }
        public IEnumerable<FlightPlan> GetAllFlightPlans()
        {
            return flightsPlansList;
        }
        public IEnumerable<Flight> GetAllFlights()
        {
            return flightsList;
        }
        public IEnumerable<Server> GetAllServers()
        {
            return serversList;
        }
        public Flight GetFlightById(string id)
        {
            Flight flight = flightsList.Where(x => x.FlightId == id).FirstOrDefault();
            if (flight == null)
            {
                Debug.WriteLine("flight isn't found.\n");
                return null;
            }
            else
            {
                return flight;
            }
        }
        public FlightPlan GetFlightPlanById(string uniqueId)
        {
            FlightPlan flightPlan = flightsPlansList.Where(x => x.UniqueId == uniqueId).FirstOrDefault();
            if (flightPlan == null)
            {
                Debug.WriteLine("flightPlan isn't found.\n");
                return null;
            }
            else
            {
                return flightPlan;
            }
        }
        public Server GetServerById(string id)
        {
            Server server = serversList.Where(x => x.ServerId == id).FirstOrDefault();
            if (server == null)
            {
                Debug.WriteLine("server isn't found.\n");
                return null;
            }
            else
            {
                return server;
            }
        }
        public void RemoveFlightPlan(string uniqueId)
        {
            FlightPlan flightPlan = flightsPlansList.Where(x => x.UniqueId == uniqueId).FirstOrDefault();
            if (flightPlan == null)
            {
                Debug.WriteLine("flightPlan isn't found.\n");
            }
            else
            {
                flightsPlansList.Remove(flightPlan);
            }
        }
        public void RemoveServer(string id)
        {
            Server server = serversList.Where(x => x.ServerId == id).FirstOrDefault();
            if (server == null)
            {
                Debug.WriteLine("server isn't found.\n");
            }
            else
            {
                serversList.Remove(server);
            }
        }
        public void UpdateFlight(Flight flight)
        {
            Flight oldFlight = flightsList.Where(x => x.FlightId == flight.FlightId).FirstOrDefault();
            oldFlight.CompanyName = flight.CompanyName;
            oldFlight.DateTime = flight.DateTime;
            oldFlight.IsExternal = flight.IsExternal;
            oldFlight.Latitude = flight.Latitude;
            oldFlight.Longitude = flight.Longitude;
            oldFlight.Passengers = flight.Passengers;
        }
    }
}
