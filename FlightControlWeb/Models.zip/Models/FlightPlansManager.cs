﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace FlightControlWeb.Models
{
    public class FlightPlanManager
    {
        //private readonly List<FlightPlan> flightsPlansList = new List<FlightPlan>(); *** old
        readonly Dictionary<string, KeyValuePair<bool, FlightPlan>> flightPlans = 
            new Dictionary<string, KeyValuePair<bool, FlightPlan>>();

        public IEnumerable<Flight> GetAllFlightsRelative(DateTime dateTime)
        {
            List<Flight> flights = new List<Flight>();
            foreach (KeyValuePair<string, KeyValuePair<bool, FlightPlan>> flightPlanKeyValuePair
                in this.flightPlans)
            {
                FlightPlan flightPlan = flightPlanKeyValuePair.Value.Value;
                string flightId = flightPlanKeyValuePair.Key;
                bool isExternal = flightPlanKeyValuePair.Value.Key;

                flights.Add(new Flight
                {
                    FlightId = flightId,
                    Longitude = flightPlan.InitialLocation.Longitude,
                    Latitude = flightPlan.InitialLocation.Latitude,
                    Passengers = flightPlan.Passengers,
                    CompanyName = flightPlan.CompanyName,
                    DateTime = flightPlan.InitialLocation.DateTime,
                    IsExternal = isExternal
                });
            }

            return flights;
        }
        public IEnumerable<Flight> GetInternalFlightsRelative(DateTime dateTime)
        {
            List<Flight> flights = new List<Flight>();
            foreach (KeyValuePair<string, KeyValuePair<bool, FlightPlan>> flightPlanKeyValuePair
                in this.flightPlans)
            {
                FlightPlan flightPlan = flightPlanKeyValuePair.Value.Value;
                string flightId = flightPlanKeyValuePair.Key;
                bool isExternal = flightPlanKeyValuePair.Value.Key;

                if (!isExternal)
                {
                    flights.Add(new Flight
                    {
                        FlightId = flightId,
                        Longitude = flightPlan.InitialLocation.Longitude,
                        Latitude = flightPlan.InitialLocation.Latitude,
                        Passengers = flightPlan.Passengers,
                        CompanyName = flightPlan.CompanyName,
                        DateTime = flightPlan.InitialLocation.DateTime,
                        IsExternal = isExternal
                    });
                }
            }

            return flights;
        }
        public void AddFlightPlan(FlightPlan flightPlan)
        {
            string uniqueId = this.GenerateHashCodeOfId();
            bool isExternal = false;
            flightPlans.Add(uniqueId, new KeyValuePair<bool, FlightPlan>(isExternal, flightPlan));
        }

        public FlightPlan GetFlightPlanById(string uniqueId)
        {
            KeyValuePair<bool, FlightPlan> output;
            bool gotValue = flightPlans.TryGetValue(uniqueId, out output);

            if (gotValue)
            {
                return output.Value;
            }
            else
            {
                //throw new Exception("No flight found");
                Debug.WriteLine("flightPlan isn't found.\n");
                return null;
            }
        }

        public void RemoveFlightPlan(string uniqueId)
        {
            this.flightPlans.Remove(uniqueId);
        }

        //Make this method better :)
        private string GenerateHashCodeOfId()
        {
            return Convert.ToBase64String(Guid.NewGuid().ToByteArray()).Substring(0, 8);
        }
    }
}
